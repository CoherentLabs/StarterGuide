function getCurrHealthPercent(current, max) {
    return (current * 100) / max;
}